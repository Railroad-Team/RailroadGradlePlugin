package dev.railroadide;

import org.gradle.api.Plugin;
import org.gradle.api.Project;

public class RailroadPlugin implements Plugin<Project> {
    @Override
    public void apply(Project project) {
        project.getLogger().lifecycle("Railroad plugin applied to project '{}'", project.getName());

        project.getTasks().register("railroadInfo", task -> {
            task.setGroup("Railroad");
            task.setDescription("Prints a simple confirmation that the Railroad plugin is active.");
            task.doLast(t ->
                    project.getLogger().lifecycle("Railroad plugin is active for '{}'", project.getName()));
        });
    }
}
